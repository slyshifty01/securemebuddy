import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";

// Debug Tools
import PopupDebugPanel from "./Components/PopupDebugPanel.jsx";
import DebugPanel from "./Components/DebugPanel.jsx";

// Developer Portal Components
import DeveloperDashboard from "./Components/DeveloperDashboard.jsx";
import AuthCallback from "./Components/AuthCallback.jsx";

const path = window.location.pathname;

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    {path === "/developer" ? (
      <DeveloperDashboard />
    ) : path === "/auth/callback" ? (
      <AuthCallback />
    ) : path === "/debug-popups" ? (
      <PopupDebugPanel />
    ) : path === "/debug" ? (
      <DebugPanel />
    ) : (
      <App />
    )}
  </React.StrictMode>
);
